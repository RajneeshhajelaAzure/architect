
<# 
deploy.ps1 — Windows 11 friendly
- Installs Node deps where needed
- Zips all lambda folders
- Creates or updates Lambda functions
#>

param(
  [string]$ConfigPath = "config\config.json"
)

# 1) Load config
if (!(Test-Path $ConfigPath)) { throw "Config file not found: $ConfigPath" }
$config   = Get-Content $ConfigPath | ConvertFrom-Json
$region   = $config.region
$roleArn  = $config.roleArn
$sender   = $config.sender
$bucket   = $config.bucket

Write-Host "Region: $region"
Write-Host "RoleArn: $roleArn"
Write-Host "Sender: $sender"
Write-Host "Bucket: $bucket"

# 2) Ensure dist folder
$dist = Join-Path (Get-Location) "dist"
if (!(Test-Path $dist)) { New-Item -ItemType Directory -Path $dist | Out-Null }

# 3) Install dependencies for lambdas that use AWS SDK v3
function Install-Npm($path) {
  Write-Host "npm install in $path"
  Push-Location $path
  if (Test-Path "package.json") {
    npm install --omit=dev
  }
  Pop-Location
}

Install-Npm ".\lambdas	extract_analyze"
Install-Npm ".\lambdas\send_email_ses"

# 4) Zip each lambda folder
function Zip-Lambda($name) {
  $src = ".\lambdas\$name\*"
  $zip = ".\dist\$name.zip"
  if (Test-Path $zip) { Remove-Item $zip -Force }
  Write-Host "Zipping $name -> $zip"
  Compress-Archive -Path $src -DestinationPath $zip
}

$lambdas = @(
  "validate_aadhaar",
  "validate_pan",
  "bank_coverage",
  "name_similarity",
  "textract_analyze",
  "send_email_ses"
)

$lambdas | ForEach-Object { Zip-Lambda $_ }

# 5) Create or update Lambda functions
function Upsert-Lambda($name) {
  $zip = ".\dist\$name.zip"
  $exists = aws lambda get-function --function-name $name --region $region 2>$null
  if ($LASTEXITCODE -eq 0 -and $exists) {
    Write-Host "Updating $name"
    aws lambda update-function-code --function-name $name `
      --zip-file fileb://$zip --region $region | Out-Null
  }
  else {
    Write-Host "Creating $name"
    aws lambda create-function --function-name $name `
      --runtime nodejs20.x --role $roleArn --handler index.handler `
      --zip-file fileb://$zip --region $region | Out-Null
  }
}

$lambdas | ForEach-Object { Upsert-Lambda $_ }

# 6) Set environment variable for SES sender (optional)
Write-Host "Setting env var SENDER on send_email_ses"
aws lambda update-function-configuration `
  --function-name send_email_ses `
  --region $region `
  --environment "Variables={SENDER=$sender}" | Out-Null

Write-Host "`n✅ Deployment complete."
Write-Host "Test examples (run one at a time):"
Write-Host "aws lambda invoke --function-name validate_aadhaar --payload '{"id_number":"123412341234"}' --cli-binary-format raw-in-base64-out out.json; Get-Content out.json"
Write-Host "aws lambda invoke --function-name textract_analyze --payload '{"bucket":"$bucket","key":"path/to/sample.pdf"}' --cli-binary-format raw-in-base64-out out.json; Get-Content out.json"
Write-Host "aws lambda invoke --function-name send_email_ses --payload '{"to":"customer@example.com","subject":"Action needed: KYC","html":"<p>Please upload remaining 5 months.</p>"}' --cli-binary-format raw-in-base64-out out.json; Get-Content out.json"
