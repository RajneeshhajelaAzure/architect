
# KYC Agent (AWS) – Windows 11 Starter Kit

This package contains a ready-to-deploy starter for an **agentic KYC validator** on AWS:
- Lambda tools (Aadhaar, PAN, bank coverage, name match, Textract OCR, SES email)
- A Windows-friendly deployment script: **deploy.ps1** (PowerShell)
- Step Functions template and Bedrock Agent instructions

## Prerequisites
1. **AWS CLI v2** installed and configured (`aws configure`).
2. **Node.js 20+** installed (`node -v`, `npm -v`).
3. **SES identity** (email/domain) verified; sandbox exit if you want to email any recipient.
4. IAM role with permissions: Lambda, S3 (read/write), Textract, SESv2, CloudWatch Logs (and KMS if SSE-KMS is used).

## Configure
Edit `config/config.json`:
```json
{
  "region": "ap-south-1",
  "bucket": "kyc-docs-yourbucket",
  "roleArn": "arn:aws:iam::123456789012:role/kyc-agent-role",
  "sender": "kyc@yourdomain.com"
}
```

## Deploy (Windows 11 / PowerShell)
Open a PowerShell terminal in the project folder and run:
```powershell
./deploy.ps1
```
The script will:
- Install Node deps for Textract/SES lambdas
- Zip all lambda folders
- Create/update Lambda functions
- Set the SES sender env var on `send_email_ses`

## Test examples
```powershell
aws lambda invoke --function-name validate_aadhaar `
  --payload '{"id_number":"123412341234"}' `
  --cli-binary-format raw-in-base64-out out.json; Get-Content out.json

aws lambda invoke --function-name textract_analyze `
  --payload '{"bucket":"kyc-docs-yourbucket","key":"path/to/sample.pdf"}' `
  --cli-binary-format raw-in-base64-out out.json; Get-Content out.json | Select-Object -First 20

aws lambda invoke --function-name send_email_ses `
  --payload '{"to":"customer@example.com","subject":"Action needed: KYC","html":"<p>Please upload remaining 5 months.</p>"}' `
  --cli-binary-format raw-in-base64-out out.json; Get-Content out.json
```

## Next: Bedrock Agent
Use `agent/AgentInstructions.md` to create a Bedrock Agent. Add action groups mapping to your Lambda ARNs and configure Guardrails.

## Optional: Step Functions
Use `infra/state-machine.json` as a starting template. Replace placeholders with your region/account before deployment.

## Security reminders
- Store **masked Aadhaar** only.
- Prefer SSE-KMS for S3 and add KMS permissions if used.
