
exports.handler = async (event) => {
  function norm(n){ return (n||'').toLowerCase().replace(/[^a-z\s]/g,'').replace(/\s+/g,' ').trim(); }
  function jaccard(a,b){ const A=new Set(norm(a).split(' ')), B=new Set(norm(b).split(' ')); const inter=[...A].filter(x=>B.has(x)).length; const union=new Set([...A,...B]).size; return union? inter/union : 0; }
  const score = jaccard(event.ovd_name, event.bank_name);
  return { score, match: score >= 0.90 };
};
