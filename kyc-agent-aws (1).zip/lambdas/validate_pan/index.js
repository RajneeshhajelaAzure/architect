
exports.handler = async (event) => {
  const pan = (event.id_number || '').toUpperCase();
  const valid = /^[A-Z]{5}(?!0000)\d{4}[A-Z]$/.test(pan);
  return { valid };
};
