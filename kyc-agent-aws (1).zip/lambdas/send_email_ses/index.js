
const { SESv2Client, SendEmailCommand } = require('@aws-sdk/client-sesv2');

function buildMime({ from, to, subject, html, attachments }) {
  const boundary = '----=_PartBoundary_' + Date.now();
  let mime = '';
  mime += `From: ${from}
`;
  mime += `To: ${to}
`;
  mime += `Subject: ${subject}
`;
  mime += 'MIME-Version: 1.0
';
  mime += `Content-Type: multipart/mixed; boundary="${boundary}"

`;
  // HTML body part
  mime += `--${boundary}
`;
  mime += 'Content-Type: text/html; charset="utf-8"
';
  mime += 'Content-Transfer-Encoding: 7bit

';
  mime += `${html}
`;
  // Attachments
  (attachments || []).forEach(a => {
    const filename = a.FileName || 'attachment.bin';
    const content = a.RawContent || '';
    const ctype = a.ContentType || 'application/octet-stream';
    mime += `--${boundary}
`;
    mime += `Content-Type: ${ctype}; name="${filename}"
`;
    mime += 'Content-Transfer-Encoding: base64
';
    mime += `Content-Disposition: attachment; filename="${filename}"

`;
    mime += `${content}
`;
  });
  mime += `--${boundary}--`;
  return mime;
}

exports.handler = async (event) => {
  const region = process.env.AWS_REGION || 'ap-south-1';
  const client = new SESv2Client({ region });
  const from = process.env.SENDER || 'kyc@yourdomain.com';
  const { to, subject, html, attachments } = event;
  if (!to || !subject || !html) return { error: 'to/subject/html required' };

  const mime = buildMime({ from, to, subject, html, attachments });
  const params = {
    FromEmailAddress: from,
    Destination: { ToAddresses: [to] },
    Content: { Raw: { Data: Buffer.from(mime) } }
  };

  const cmd = new SendEmailCommand(params);
  const resp = await client.send(cmd);
  return { messageId: resp.MessageId || 'sent' };
};
