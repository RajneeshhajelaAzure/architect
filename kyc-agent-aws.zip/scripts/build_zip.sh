
#!/usr/bin/env bash
set -euo pipefail
mkdir -p dist

for fn in validate_aadhaar validate_pan bank_coverage name_similarity textract_analyze send_email_ses; do
  pushd lambdas/$fn > /dev/null
  npm install --omit=dev
  zip -r ../../dist/${fn}.zip . -x "node_modules/.cache/*"
  popd > /dev/null
  echo "Built dist/${fn}.zip"
done
