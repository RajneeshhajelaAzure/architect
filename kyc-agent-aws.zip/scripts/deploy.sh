
#!/usr/bin/env bash
set -euo pipefail
CONF=$(cat config/config.json)
REGION=$(echo "$CONF" | python -c "import sys, json; print(json.load(sys.stdin)['region'])")
ROLE=$(echo "$CONF" | python -c "import sys, json; print(json.load(sys.stdin)['roleArn'])")

FUNCTIONS=(validate_aadhaar validate_pan bank_coverage name_similarity textract_analyze send_email_ses)

for FN in "${FUNCTIONS[@]}"; do
  ZIP=dist/${FN}.zip
  if aws lambda get-function --function-name "$FN" --region "$REGION" >/dev/null 2>&1; then
    echo "Updating $FN"
    aws lambda update-function-code --function-name "$FN" --zip-file fileb://$ZIP --region "$REGION" >/dev/null
  else
    echo "Creating $FN"
    aws lambda create-function --function-name "$FN"       --runtime nodejs20.x --role "$ROLE" --handler index.handler       --zip-file fileb://$ZIP --region "$REGION" >/dev/null
  fi
  echo "Deployed $FN"
done
