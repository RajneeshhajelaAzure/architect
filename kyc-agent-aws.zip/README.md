
# KYC Agent (AWS + VS Code) – Starter Kit

This project scaffolds an **agentic KYC validator** on AWS: Lambdas for deterministic checks (Aadhaar, PAN, bank coverage, name match), Textract OCR, SES email, and a Step Functions state machine template. You will later plug these tools into an **Amazon Bedrock Agent**.

> Authoritative docs: 
> - Amazon Textract `AnalyzeDocument` (FORMS/TABLES): https://docs.aws.amazon.com/textract/latest/dg/API_AnalyzeDocument.html 
> - Amazon Bedrock (agents/guardrails/KB): https://docs.aws.amazon.com/bedrock/ 
> - Amazon SES v2 sending (API) + attachments: https://docs.aws.amazon.com/ses/latest/dg/send-email-api.html and https://aws.amazon.com/about-aws/whats-new/2025/04/amazon-ses-attachments-sending-apis/
> - S3 encryption defaults (SSE-S3/SSE-KMS): https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingEncryption.html

---

## 1) Prerequisites
- AWS account with IAM permissions to create Lambda, S3, Textract, SES, Step Functions, KMS.
- **AWS CLI** installed and configured (`aws configure`).
- **Node.js 20+** on your machine.
- (Recommended) Verify sender email/domain in **Amazon SES** (Console → SES → Verified identities). If in sandbox, request **production access**.

## 2) Configure
Edit `config/config.json`:
```json
{
  "region": "ap-south-1",
  "bucket": "kyc-docs-yourbucket",
  "roleArn": "arn:aws:iam::123456789012:role/kyc-agent-role",
  "sender": "kyc@yourdomain.com"
}
```
- `roleArn`: IAM role for Lambda (trust: lambda.amazonaws.com) with permissions: S3 (read/write), Textract, SESv2, CloudWatch Logs, Bedrock (later). If you use SSE-KMS, add KMS key usage to this role and key policy.

## 3) Build Lambda packages
Install dependencies and create deployment zips:
```bash
bash scripts/build_zip.sh
```
This will run `npm install` inside each Lambda folder and produce zips in `dist/`.

## 4) Deploy Lambdas (dev)
```bash
bash scripts/deploy.sh
```
The script reads `config/config.json` and creates/updates these functions:
- `validate_aadhaar`
- `validate_pan`
- `bank_coverage`
- `name_similarity`
- `textract_analyze`
- `send_email_ses`

## 5) Test locally (invoke with AWS CLI)
Example: Aadhaar validator
```bash
aws lambda invoke   --function-name validate_aadhaar   --payload '{"id_number":"123412341234"}'   --cli-binary-format raw-in-base64-out out.json && cat out.json
```

Textract analyze (provide an S3 object):
```bash
aws lambda invoke   --function-name textract_analyze   --payload '{"bucket":"your-bucket","key":"path/to/doc.pdf"}'   --cli-binary-format raw-in-base64-out out.json && head -c 400 out.json
```

SES email:
```bash
aws lambda invoke   --function-name send_email_ses   --payload '{"to":"customer@example.com","subject":"Action needed: KYC","html":"<p>Please upload remaining 5 months.</p>"}'   --cli-binary-format raw-in-base64-out out.json && cat out.json
```
> SES v2 `sendEmail` Simple content with optional attachments is supported (Apr 4, 2025). Ensure identity is verified and account is out of sandbox. 

## 6) Step Functions (optional) – Orchestration template
Edit `infra/state-machine.json` to replace placeholders and deploy via console or CLI. Use **Map** for multi‑doc parallel processing and **Choice** to route PASS/PENDING/HITL.

## 7) Next: Bedrock Agent
Create an **Amazon Bedrock Agent**, attach these Lambdas as **action group tools**, add your **KYC Knowledge Base** (RBI OVD + UIDAI masking/offline e‑KYC), and configure **Guardrails** (mask Aadhaar, require ≥2 OVDs). See Bedrock docs. 

## 8) Security reminders
- S3 default encryption is enabled; for stricter control, set SSE‑KMS and update IAM/KMS policies. 
- Store **masked Aadhaar** only, per UIDAI/RBI guidance.

---

### Troubleshooting
- Textract permissions: ensure `AmazonTextractFullAccess` on the role. 
- SES errors: verify identity & sandbox exit; check region endpoints.
- Lambda runtime: Node.js 20.x includes no AWS SDK by default—this project bundles `@aws-sdk/client-*` in each Lambda.

