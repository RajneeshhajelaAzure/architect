
const { TextractClient, AnalyzeDocumentCommand } = require('@aws-sdk/client-textract');

exports.handler = async (event) => {
  const region = process.env.AWS_REGION || 'ap-south-1';
  const client = new TextractClient({ region });
  const bucket = event.bucket, key = event.key;
  if (!bucket || !key) return { error: 'bucket/key required' };

  const cmd = new AnalyzeDocumentCommand({
    Document: { S3Object: { Bucket: bucket, Name: key } },
    FeatureTypes: ['FORMS','TABLES']
  });

  const resp = await client.send(cmd);
  // Return raw blocks for now; agent will interpret
  return { blocks: resp.Blocks || [], pages: (resp.Blocks||[]).filter(b=>b.BlockType==='PAGE').length };
};
