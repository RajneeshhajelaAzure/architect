
const { SESv2Client, SendEmailCommand } = require('@aws-sdk/client-sesv2');

exports.handler = async (event) => {
  const region = process.env.AWS_REGION || 'ap-south-1';
  const client = new SESv2Client({ region });
  const { to, subject, html, attachments } = event;
  if (!to || !subject || !html) return { error: 'to/subject/html required' };

  const params = {
    Destination: { ToAddresses: [to] },
    FromEmailAddress: process.env.SENDER || 'kyc@yourdomain.com',
    Content: {
      Simple: {
        Subject: { Data: subject },
        Body: { Html: { Data: html } },
        ...(attachments && attachments.length ? { Attachments: attachments.map(a => ({
          FileName: a.FileName,
          ContentTransferEncoding: a.ContentTransferEncoding || 'BASE64',
          RawContent: a.RawContent,
          ContentDisposition: a.ContentDisposition || 'ATTACHMENT',
          ContentDescription: a.ContentDescription || a.FileName
        })) } : {})
      }
    }
  };

  const cmd = new SendEmailCommand(params);
  const resp = await client.send(cmd);
  return { messageId: resp.MessageId || 'sent' };
};
