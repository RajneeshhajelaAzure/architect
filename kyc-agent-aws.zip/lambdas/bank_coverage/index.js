
exports.handler = async (event) => {
  const { earliest, latest } = event;
  function monthsBetween(s, e){ const start = new Date(s), end = new Date(e); return (end.getFullYear()-start.getFullYear())*12 + (end.getMonth()-start.getMonth()) + 1; }
  const months = (earliest && latest) ? monthsBetween(earliest, latest) : 0;
  return { months, ok: months >= 6 };
};
